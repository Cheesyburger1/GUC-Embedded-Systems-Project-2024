#ifndef MPU6050_H
#define MPU6050_H

#include <stdint.h>
#include <stdbool.h>

#define ALPHA_FILTER          0.95f   // Low-pass filter coefficient
#define NOISE_THRESHOLD       0.05f   // Smaller threshold for better sensitivity
#define VELOCITY_DECAY        0.99f   // Slower velocity decay
#define MAX_VELOCITY          5.0f    // Lower maximum velocity
// MPU6050 I2C address
#define MPU6050_ADDRESS     0x68

// MPU6050 registers
#define MPU6050_REG_SMPLRT_DIV      0x19
#define MPU6050_REG_CONFIG          0x1A
#define MPU6050_REG_GYRO_CONFIG     0x1B
#define MPU6050_REG_ACCEL_CONFIG    0x1C
#define MPU6050_REG_ACCEL_XOUT_H    0x3B
#define MPU6050_REG_ACCEL_XOUT_L    0x3C
#define MPU6050_REG_ACCEL_YOUT_H    0x3D
#define MPU6050_REG_ACCEL_YOUT_L    0x3E
#define MPU6050_REG_ACCEL_ZOUT_H    0x3F
#define MPU6050_REG_ACCEL_ZOUT_L    0x40
#define MPU6050_REG_PWR_MGMT_1      0x6B
#define MPU6050_REG_WHO_AM_I        0x75

// Accelerometer scale ranges
typedef enum {
    ACCEL_RANGE_2G = 0,    // ±2g
    ACCEL_RANGE_4G = 1,    // ±4g
    ACCEL_RANGE_8G = 2,    // ±8g
    ACCEL_RANGE_16G = 3    // ±16g
} mpu6050_accel_range_t;

// Structure to hold raw accelerometer data
typedef struct {
    float x;
    float y;
    float z;
} mpu6050_accel_t;

// Structure to hold processed motion data
typedef struct {
    float accel_x;
    float accel_y;
    float accel_z;
    float velocity_x;
    float velocity_y;
    float velocity_z;
    float true_accel_x;
    float true_accel_y;
    float true_accel_z;
} mpu6050_motion_t;

// Function prototypes
bool mpu6050_init(void);
uint8_t mpu6050_read_id(void);
bool mpu6050_write_reg(uint8_t reg, uint8_t data);
uint8_t mpu6050_read_reg(uint8_t reg);
void mpu6050_set_accel_range(mpu6050_accel_range_t range);
void mpu6050_read_accel_raw(int16_t *x, int16_t *y, int16_t *z);
void mpu6050_read_accel(mpu6050_accel_t *data);
float mpu6050_get_accel_resolution(void);
void mpu6050_calibrate(void);
void mpu6050_process_motion(mpu6050_motion_t *motion);
void mpu6050_reset_velocity(void);

#endif // MPU6050_H