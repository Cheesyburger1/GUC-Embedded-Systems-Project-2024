#ifndef ULTRASONIC_H
#define ULTRASONIC_H

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"

#define BUZZER_PIN 15    // GP15 for buzzer
#define DISTANCE_THRESHOLD 5.0f  // 5cm threshold

// Function declarations
void ultrasonic_init(uint trigger_pin, uint echo_pin);
float ultrasonic_get_distance(void);
void buzzer_init(void);
void buzzer_set(bool state);

#endif // ULTRASONIC_H