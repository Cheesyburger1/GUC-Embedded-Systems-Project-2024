#include "ultraSonic.h"
#include <stdlib.h>
#include <time.h>



static uint TRIG_PIN;
static uint ECHO_PIN;
static bool rng_initialized = false;

void buzzer_init(void) {
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
    gpio_put(BUZZER_PIN, 0);  // Start with buzzer off
    
    // Initialize random number generator
    if (!rng_initialized) {
        srand(time(NULL));
        rng_initialized = true;
    }
}

void buzzer_set(bool state) {
    gpio_put(BUZZER_PIN, state);
}



void ultrasonic_init(uint trigger_pin, uint echo_pin) {
    TRIG_PIN = trigger_pin;
    ECHO_PIN = echo_pin;
    
    // Initialize trigger pin as output
    gpio_init(TRIG_PIN);
    gpio_set_dir(TRIG_PIN, GPIO_OUT);
    gpio_put(TRIG_PIN, 0);
    
    // Initialize echo pin as input with pull-down
    gpio_init(ECHO_PIN);
    gpio_set_dir(ECHO_PIN, GPIO_IN);
    gpio_pull_down(ECHO_PIN);
}

float ultrasonic_get_distance(void) {
    // Send trigger pulse
    gpio_put(TRIG_PIN, 1);
    sleep_us(10);  // 10 microseconds trigger pulse
    gpio_put(TRIG_PIN, 0);
    
    // Wait for echo to go high
    uint timeout = 0;
    while (gpio_get(ECHO_PIN) == 0 && timeout < 30000) {
        timeout++;
        sleep_us(1);
    }
    
    if (timeout >= 30000) {
        printf("Timeout waiting for echo to go high\n");
        return -1.0f; // Timeout error
    }
    
    // Measure pulse width
    absolute_time_t start = get_absolute_time();
    
    timeout = 0;
    while (gpio_get(ECHO_PIN) == 1 && timeout < 30000) {
        timeout++;
        sleep_us(1);
    }
    
    absolute_time_t end = get_absolute_time();
    
    if (timeout >= 30000) {
        printf("Timeout waiting for echo to go low\n");
        return -1.0f; // Timeout error
    }
    
    // Calculate distance
    int64_t pulse_duration = absolute_time_diff_us(start, end);
    float distance_cm = (float)pulse_duration / 58.0f;
    
    // If object is detected within threshold, generate and output GUC-like coordinates
    if (distance_cm > 0 && distance_cm < DISTANCE_THRESHOLD) {
        
        printf("\nALERT - Object Detected!\n");
        
        printf("Distance: %.2f cm\n", distance_cm);
        printf(" - Possible obstruction detected\n");
    }
    
    return distance_cm;
}