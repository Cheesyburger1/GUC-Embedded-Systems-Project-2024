#include "mpu6050.h"
#include "hardware/i2c.h"
#include "pico/stdlib.h"
#include <stdio.h>
#include <math.h>

// I2C instance to use
#define I2C_PORT i2c0

// Current accelerometer range setting
static mpu6050_accel_range_t current_range = ACCEL_RANGE_2G;

// Calibration offsets
static float offset_x = 0.0f;
static float offset_y = 0.0f;
static float offset_z = 0.0f;

// Previous timestamp for integration
static uint64_t last_time = 0;

// Low-pass filter coefficient (0 to 1, higher = more smoothing)
//#define ALPHA 0.95f

bool mpu6050_write_reg(uint8_t reg, uint8_t data) {
    uint8_t buf[2] = {reg, data};
    int ret = i2c_write_blocking(I2C_PORT, MPU6050_ADDRESS, buf, 2, false);
    if (ret < 0) {
        printf("Failed to write to register 0x%02X with value 0x%02X\n", reg, data);
        return false;
    }
    return true;
}

uint8_t mpu6050_read_reg(uint8_t reg) {
    uint8_t data;
    i2c_write_blocking(I2C_PORT, MPU6050_ADDRESS, &reg, 1, true);
    i2c_read_blocking(I2C_PORT, MPU6050_ADDRESS, &data, 1, false);
    return data;
}

uint8_t mpu6050_read_id(void) {
    return mpu6050_read_reg(MPU6050_REG_WHO_AM_I);
}

bool mpu6050_init(void) {
    printf("Starting GY-87/MPU6050 initialization...\n");
    
    // Check device ID
    uint8_t id = mpu6050_read_id();
    printf("Device ID: 0x%02X\n", id);
    
    // Reset the device
    printf("Resetting device...\n");
    if (!mpu6050_write_reg(MPU6050_REG_PWR_MGMT_1, 0x80)) {
        printf("Failed to reset device\n");
        return false;
    }
    sleep_ms(100);

    // Wake up the MPU6050
    printf("Waking up device...\n");
    if (!mpu6050_write_reg(MPU6050_REG_PWR_MGMT_1, 0x00)) {
        printf("Failed to wake up device\n");
        return false;
    }
    sleep_ms(100);

    // Verify device is responsive after reset
    id = mpu6050_read_id();
    printf("Device ID after reset: 0x%02X\n", id);

    // Configure power management
    printf("Configuring power management...\n");
    if (!mpu6050_write_reg(MPU6050_REG_PWR_MGMT_1, 0x01)) {
        printf("Failed to configure power management\n");
        return false;
    }

    // Configure sample rate divider
    printf("Setting sample rate divider...\n");
    if (!mpu6050_write_reg(MPU6050_REG_SMPLRT_DIV, 0x07)) {
        printf("Failed to set sample rate\n");
        return false;
    }

    // Configure DLPF
    printf("Setting digital low-pass filter...\n");
    if (!mpu6050_write_reg(MPU6050_REG_CONFIG, 0x06)) {
        printf("Failed to set DLPF\n");
        return false;
    }

    // Set accelerometer range
    printf("Setting accelerometer range...\n");
    if (!mpu6050_write_reg(MPU6050_REG_ACCEL_CONFIG, (ACCEL_RANGE_2G << 3))) {
        printf("Failed to set accelerometer range\n");
        return false;
    }
    current_range = ACCEL_RANGE_2G;

    // Configure I2C bypass
    printf("Configuring I2C bypass...\n");
    if (!mpu6050_write_reg(0x37, 0x02)) {
        printf("Failed to configure I2C bypass\n");
        return false;
    }

    printf("GY-87/MPU6050 initialization complete!\n");
    return true;
}

void mpu6050_calibrate(void) {
    printf("Calibrating MPU6050...\n");
    printf("Keep sensor level with Z up. Wait...\n");
    
    float sum_x = 0, sum_y = 0, sum_z = 0;
    const int samples = 200;  
    
    sleep_ms(2000);  // Longer settling time
    
    for(int i = 0; i < samples; i++) {
        mpu6050_accel_t data;
        mpu6050_read_accel(&data);
        
        sum_x += data.x;
        sum_y += data.y;
        sum_z += data.z;
        
        sleep_ms(10);
    }
    
    // When at rest, we expect: x=0, y=0, z=1
    offset_x = sum_x / samples;
    offset_y = sum_y / samples;
    offset_z = sum_z / samples - 1.0f;  // Z should read 1g when vertical
    
    printf("Calibration complete!\n");
    printf("Raw calibration values: X=%f, Y=%f, Z=%f\n", sum_x/samples, sum_y/samples, sum_z/samples);
    printf("Offsets applied: X=%f, Y=%f, Z=%f\n", offset_x, offset_y, offset_z);
}

void mpu6050_set_accel_range(mpu6050_accel_range_t range) {
    mpu6050_write_reg(MPU6050_REG_ACCEL_CONFIG, range << 3);
    current_range = range;
}

void mpu6050_read_accel_raw(int16_t *x, int16_t *y, int16_t *z) {
    uint8_t buffer[6];
    uint8_t reg = MPU6050_REG_ACCEL_XOUT_H;
    
    i2c_write_blocking(I2C_PORT, MPU6050_ADDRESS, &reg, 1, true);
    i2c_read_blocking(I2C_PORT, MPU6050_ADDRESS, buffer, 6, false);

    *x = (buffer[0] << 8) | buffer[1];
    *y = (buffer[2] << 8) | buffer[3];
    *z = (buffer[4] << 8) | buffer[5];
}

float mpu6050_get_accel_resolution(void) {
    switch (current_range) {
        case ACCEL_RANGE_2G:
            return 2.0f / 32768.0f;
        case ACCEL_RANGE_4G:
            return 4.0f / 32768.0f;
        case ACCEL_RANGE_8G:
            return 8.0f / 32768.0f;
        case ACCEL_RANGE_16G:
            return 16.0f / 32768.0f;
        default:
            return 0.0f;
    }
}

void mpu6050_read_accel(mpu6050_accel_t *data) {
    int16_t x, y, z;
    float resolution = mpu6050_get_accel_resolution();

    mpu6050_read_accel_raw(&x, &y, &z);

    data->x = x * resolution;
    data->y = y * resolution;
    data->z = z * resolution;
}

void mpu6050_reset_velocity(void) {
    last_time = time_us_64();
}

// Remove or comment out the old define
// #define ALPHA 0.95f

void mpu6050_process_motion(mpu6050_motion_t *motion) {
    static float last_accel_x = 0;
    static float last_accel_y = 0;
    static float last_accel_z = 0;
    
    mpu6050_accel_t raw_data;
    mpu6050_read_accel(&raw_data);
    
    // Store raw values
    motion->accel_x = raw_data.x;
    motion->accel_y = raw_data.y;
    motion->accel_z = raw_data.z;

    // Remove offsets, Z should be ~1g at rest
    float accel_x = raw_data.x - offset_x;
    float accel_y = raw_data.y - offset_y;
    float accel_z = raw_data.z - offset_z;

    // Calculate total acceleration magnitude before removing gravity
    float total_accel = sqrtf(accel_x * accel_x + accel_y * accel_y + accel_z * accel_z);
    
    // Only apply filtering to the dynamic component
    float dynamic_x = ALPHA_FILTER * last_accel_x + (1.0f - ALPHA_FILTER) * accel_x;
    float dynamic_y = ALPHA_FILTER * last_accel_y + (1.0f - ALPHA_FILTER) * accel_y;
    float dynamic_z = ALPHA_FILTER * last_accel_z + (1.0f - ALPHA_FILTER) * (accel_z - 1.0f);
    
    motion->true_accel_x = dynamic_x;
    motion->true_accel_y = dynamic_y;
    motion->true_accel_z = dynamic_z;
    
    last_accel_x = dynamic_x;
    last_accel_y = dynamic_y;
    last_accel_z = dynamic_z;
    
    uint64_t current_time = time_us_64();
    float dt = (current_time - last_time) / 1000000.0f;
    last_time = current_time;

    // More aggressive velocity decay when acceleration is low
    float decay = (total_accel < 0.1f) ? 0.8f : VELOCITY_DECAY;
    motion->velocity_x *= decay;
    motion->velocity_y *= decay;
    motion->velocity_z *= decay;

    // Only integrate accelerations above threshold
    if (fabs(dynamic_x) > NOISE_THRESHOLD) {
        motion->velocity_x += dynamic_x * dt * 9.81f;
    }
    if (fabs(dynamic_y) > NOISE_THRESHOLD) {
        motion->velocity_y += dynamic_y * dt * 9.81f;
    }
    if (fabs(dynamic_z) > NOISE_THRESHOLD) {
        motion->velocity_z += dynamic_z * dt * 9.81f;
    }

    // Zero very small velocities
    const float MIN_VELOCITY = 0.01f;
    if (fabs(motion->velocity_x) < MIN_VELOCITY) motion->velocity_x = 0;
    if (fabs(motion->velocity_y) < MIN_VELOCITY) motion->velocity_y = 0;
    if (fabs(motion->velocity_z) < MIN_VELOCITY) motion->velocity_z = 0;

    // Cap maximum velocities
    if (fabs(motion->velocity_x) > MAX_VELOCITY) {
        motion->velocity_x = (motion->velocity_x > 0) ? MAX_VELOCITY : -MAX_VELOCITY;
    }
    if (fabs(motion->velocity_y) > MAX_VELOCITY) {
        motion->velocity_y = (motion->velocity_y > 0) ? MAX_VELOCITY : -MAX_VELOCITY;
    }
    if (fabs(motion->velocity_z) > MAX_VELOCITY) {
        motion->velocity_z = (motion->velocity_z > 0) ? MAX_VELOCITY : -MAX_VELOCITY;
    }
}