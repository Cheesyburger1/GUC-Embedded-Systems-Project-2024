#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "hardware/uart.h"
#include "mpu6050.h"
#include "ultraSonic.h"
#include "neo_7m.h"

// I2C defines
#define I2C_PORT i2c0
#define I2C_SDA 8
#define I2C_SCL 9

// Ultrasonic pins
#define TRIG_PIN 2
#define ECHO_PIN 3

// History buffer size (10 samples = 1 second at 100ms intervals)
#define HISTORY_SIZE 10
#define CRITICAL_DISTANCE 5.0f  // 5cm threshold

// Structures for historical data
typedef struct {
    float accel_x;
    float accel_y;
    float accel_z;
    uint32_t timestamp;
} motion_history_t;

typedef struct {
    gps_data_t data;
    uint32_t timestamp;
} gps_history_t;

// Circular buffers for historical data
static motion_history_t motion_history[HISTORY_SIZE];
static gps_history_t gps_history[HISTORY_SIZE];
static int motion_history_index = 0;
static int gps_history_index = 0;

// Function prototypes
void initialize_peripherals(void);
void process_sensor_data(void);
void store_motion_history(mpu6050_motion_t *motion);
void store_gps_history(gps_data_t *gps_data);
void report_historical_data(void);
void check_motion_alerts(mpu6050_motion_t *motion);
void display_gps_data(gps_data_t *gps_data);

int main() {
    stdio_init_all();
    printf("\nInitializing integrated sensor system...\n");
    
    // Initialize all peripherals
    initialize_peripherals();
    
    // Main loop
    while (1) {
        process_sensor_data();
        sleep_ms(100);  // 10Hz sampling rate
    }
    
    return 0;
}

void initialize_peripherals(void) {
    // Initialize I2C for MPU6050
    i2c_init(I2C_PORT, 400000);
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);
    
    // Initialize MPU6050
    if (!mpu6050_init()) {
        printf("MPU6050 initialization failed!\n");
        while (1) {
            printf(".");
            sleep_ms(1000);
        }
    }
    
    // Perform initial calibration
    mpu6050_calibrate();
    mpu6050_reset_velocity();
    
    // Initialize Ultrasonic sensor
    ultrasonic_init(TRIG_PIN, ECHO_PIN);
    buzzer_init();
    
    // Initialize GPS
    gps_init();
    
    // Initialize history buffers
    memset(motion_history, 0, sizeof(motion_history));
    memset(gps_history, 0, sizeof(gps_history));
    
    printf("All peripherals initialized successfully!\n");
    sleep_ms(1000);
}

void store_motion_history(mpu6050_motion_t *motion) {
    motion_history[motion_history_index].accel_x = motion->true_accel_x;
    motion_history[motion_history_index].accel_y = motion->true_accel_y;
    motion_history[motion_history_index].accel_z = motion->true_accel_z;
    motion_history[motion_history_index].timestamp = to_ms_since_boot(get_absolute_time());
    
    motion_history_index = (motion_history_index + 1) % HISTORY_SIZE;
}

void store_gps_history(gps_data_t *gps_data) {
    if (gps_data->fix_valid) {
        gps_history[gps_history_index].data = *gps_data;
        gps_history[gps_history_index].timestamp = to_ms_since_boot(get_absolute_time());
        gps_history_index = (gps_history_index + 1) % HISTORY_SIZE;
    }
}

void report_historical_data(void) {
    uint32_t current_time = to_ms_since_boot(get_absolute_time());
    uint32_t target_time = current_time - 1000; // 1 second ago
    
    // Find closest historical motion data
    int closest_motion_idx = 0;
    uint32_t closest_motion_diff = UINT32_MAX;
    
    for (int i = 0; i < HISTORY_SIZE; i++) {
        uint32_t diff = abs(motion_history[i].timestamp - target_time);
        if (diff < closest_motion_diff) {
            closest_motion_diff = diff;
            closest_motion_idx = i;
        }
    }
    
    // Find closest historical GPS data
    int closest_gps_idx = 0;
    uint32_t closest_gps_diff = UINT32_MAX;
    
    for (int i = 0; i < HISTORY_SIZE; i++) {
        if (gps_history[i].data.fix_valid) {
            uint32_t diff = abs(gps_history[i].timestamp - target_time);
            if (diff < closest_gps_diff) {
                closest_gps_diff = diff;
                closest_gps_idx = i;
            }
        }
    }
    
    // Report the historical data
    printf("\n!!! CRITICAL PROXIMITY ALERT !!!\n");
    printf("Historical data from 1 second ago:\n");
    
    // Motion data
    printf("Acceleration (g): X=%.2f, Y=%.2f, Z=%.2f\n",
           motion_history[closest_motion_idx].accel_x,
           motion_history[closest_motion_idx].accel_y,
           motion_history[closest_motion_idx].accel_z);
    
    // GPS data
    if (gps_history[closest_gps_idx].data.fix_valid) {
        printf("Location: %.6f, %.6f\n",
               gps_history[closest_gps_idx].data.latitude,
               gps_history[closest_gps_idx].data.longitude);
        printf("Altitude: %.1f m\n", 
               gps_history[closest_gps_idx].data.altitude);
    } else {
        printf("No valid GPS fix in history\n");
    }
}

void process_sensor_data(void) {
    static mpu6050_motion_t motion = {0};
    static gps_data_t gps_data = {0};
    static uint32_t last_gps_read = 0;
    static uint32_t last_ultrasonic_read = 0;
    static bool alert_triggered = false;
    uint32_t current_time = to_ms_since_boot(get_absolute_time());
    
    // Process MPU6050 motion data continuously
    mpu6050_process_motion(&motion);
    store_motion_history(&motion);
    
    // Read GPS data every 1 second
    if (current_time - last_gps_read >= 1000) {
        if (gps_read_data(&gps_data)) {
            store_gps_history(&gps_data);
        }
        last_gps_read = current_time;
    }
    
    // Read ultrasonic sensor every 100ms
    if (current_time - last_ultrasonic_read >= 100) {
        float distance = ultrasonic_get_distance();
        
        if (distance > 0 && distance < CRITICAL_DISTANCE) {
            if (!alert_triggered) {  // Only trigger once per event
                buzzer_set(true);
                report_historical_data();
                sleep_ms(100);
                buzzer_set(false);
                alert_triggered = true;
            }
        } else {
            alert_triggered = false;  // Reset trigger when distance increases
        }
        
        last_ultrasonic_read = current_time;
    }
}